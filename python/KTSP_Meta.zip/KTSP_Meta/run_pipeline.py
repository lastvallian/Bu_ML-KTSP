#!/usr/bin/env python
# coding: utf-8

# In[2]:


from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from pipe_line.KTSP_Meta_Pipeline import MetaPipeline
from models.multi_model_trainer import SKLearnModelWrapper
from models.multi_model_trainer import ShrinkageCentroidClassifier
from models.Ktsp_model import KTSPClassifier
def run_ktsp_pipeline(
    #model_name:str,
    models_names:list[str],
    data_path:str,
    use_pca:bool
):

    models = {
    "Linear SVM": SKLearnModelWrapper(SVC(kernel="linear", C=1, probability=True)),
    "RBF SVM": SKLearnModelWrapper(SVC(kernel="rbf", C=5, gamma=0.05, probability=True)),
    "Decision Tree": SKLearnModelWrapper(DecisionTreeClassifier()),
    "Naive Bayes": SKLearnModelWrapper(GaussianNB()),
    "kNN": SKLearnModelWrapper(KNeighborsClassifier(n_neighbors=5)),
    "KTSP": KTSPClassifier(top_genes=300, top_pairs=10),
    "Custom SVMTrainer":SKLearnModelWrapper(ShrinkageCentroidClassifier(shrinkage=2.0))
    }
     
    clean_names = []    
    for name in models_names:
        actual_name = name[0] if isinstance(name, list) else name
        
        if actual_name not in models:
            raise ValueError(f"Model '{actual_name}' is not supported. Supported: {list(models.keys())}")
        clean_names.append(actual_name)

    results_list=[]
    
    for model_name  in models_names:
        print(f"\n====Training {model_name}===")
        model_name = model_name[0] if isinstance(model_name, list) else model_name
        model_instance = {model_name: models[model_name]}
        pipeline = MetaPipeline(model_instance)
        raw_result=pipeline.run(data_path,model=model_instance,use_subspace=use_pca)
        result = raw_result[model_name] if model_name in raw_result else raw_result
        results_list.append({"model":model_name,
                           "accuracy":result["accuracy"],
                           "roc":result["roc"],
                            "confusion_matrix":result["confusion_matrix"],
                            "heatmap":result.get("heatmap")})
    return results_list
     

