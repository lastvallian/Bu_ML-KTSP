#!/usr/bin/env python
# coding: utf-8

# In[7]:


import sys
sys.path.append(r"C:\Users\Administrator\KTSP")
import shutil
import json
from fastapi import FastAPI,UploadFile,File,Form
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from run_pipeline import run_ktsp_pipeline

app= FastAPI()
origins=[
    "http://localhost:3000",
    "http://127.0.0.1:3000"
];

app.add_middleware(
     CORSMiddleware,
     allow_origins=origins,
     allow_credentials=True,
     allow_methods=["*"],
     allow_headers=["*"]
)

import numpy as np

def to_json_safe(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, np.generic):  # np.int64 / np.float64
        return obj.item()
    if isinstance(obj, dict):
        return {k: to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [to_json_safe(v) for v in obj]
    return obj


@app.post("/upload")
async def upload_file(file:UploadFile=File(...)):
    #tempraily keep file
    temp_path=f"temp_{data_file.filenam}" 
    with open(temp_path,"wb") as f:
        shutil.copyfileobj(data_file.file,f)
        return {"filename":file.filename,"save as":temp_path}   

class PipelineRequest(BaseModel):
    model_name:str
    data_path:str
    use_pca:str

@app.post("/run")
def run_pipeline(
    file:UploadFile=File(...),
    models_names: str = Form(...),
    use_pca: str = Form("false")):
    ##req:PipelineRequest):
    
    #save temp file
    temp_path = f"temp_{file.filename}"
    with open(temp_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    model_list=json.loads(models_names)
    actual_use_pca = True if use_pca.lower() == "true" else False
    results=run_ktsp_pipeline(
        models_names=model_list,
        data_path= temp_path,
        use_pca=actual_use_pca
    )
    
    return{
       ## "accuracy": to_json_safe(results["accuracy"]),
       ##"roc": to_json_safe(results.get("roc")),
       ## "confusion_matrix": to_json_safe(results.get("confusion_matrix"))
       "results":to_json_safe(results)
    }

